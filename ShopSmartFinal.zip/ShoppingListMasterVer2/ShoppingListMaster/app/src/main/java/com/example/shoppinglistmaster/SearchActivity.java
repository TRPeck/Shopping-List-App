package com.example.shoppinglistmaster;

import android.annotation.SuppressLint;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.shoppinglistmaster.adapter.ItemAdapter;
import com.example.shoppinglistmaster.database.DatabaseAccess;
import com.example.shoppinglistmaster.database.ItemDBHelper;
import com.example.shoppinglistmaster.model.Item;
import com.example.shoppinglistmaster.model.map;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {
    // activity that is required to implement the android search dialog

    private ListView listViewItem;
    private static ArrayList<Item> itemList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        setTitle("Search");

        //Toolbar toolbar = findViewById(R.id.searchToolbar);
        //toolbar.inflateMenu(R.menu.menu_search);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav);
        bottomNavigationView.setSelectedItemId(R.id.search);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.dashboard:
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        overridePendingTransition(0,0);
                    case R.id.search:
                        return true;
                    case R.id.map:
                        startActivity(new Intent(getApplicationContext(), map.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });


        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
        databaseAccess.open();

        initView();
        loadData();

        databaseAccess.close();


    }


    private void initView(){
        listViewItem = findViewById(R.id.searchList);
        registerForContextMenu(listViewItem);
    }

    private void loadData(){
        ItemDBHelper itemDBHelper = new ItemDBHelper(getApplicationContext());
        ArrayList<Item> items = itemDBHelper.findAll();
        if(items != null){
            listViewItem.setAdapter(new ItemAdapter(getApplicationContext(), items));
        }
    }

    @SuppressLint("ResourceType")
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.itemsearch).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setIconifiedByDefault(true);
        searchView.setIconified(false);
        searchView.setSubmitButtonEnabled(true);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchItem(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchItem(newText);
                return false;
            }
        });

        return true;
    }

    private void searchItem(String keyword) {
        ItemDBHelper itemDBHelper = new ItemDBHelper(getApplicationContext());
        ArrayList<Item> items = itemDBHelper.search(keyword);
        if(items != null){
            listViewItem.setAdapter(new ItemAdapter(getApplicationContext(), items));
        }
    }

}